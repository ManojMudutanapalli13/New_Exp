import { Component } from '@angular/core';

@Component({
  selector: 'app-six',
  standalone: false,
  
  templateUrl: './six.component.html',
  styleUrl: './six.component.css'
})
export class SixComponent {

}
