import { Component } from '@angular/core';

@Component({
  selector: 'app-two',
  standalone: false,
  
  templateUrl: './two.component.html',
  styleUrl: './two.component.css'
})
export class TwoComponent {

}
