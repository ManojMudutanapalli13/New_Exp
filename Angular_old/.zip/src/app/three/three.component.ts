import { Component } from '@angular/core';

@Component({
  selector: 'app-three',
  standalone: false,
  
  templateUrl: './three.component.html',
  styleUrl: './three.component.css'
})
export class ThreeComponent {

}
