import { Component } from '@angular/core';

@Component({
  selector: 'app-five',
  standalone: false,
  
  templateUrl: './five.component.html',
  styleUrl: './five.component.css'
})
export class FiveComponent {

}
