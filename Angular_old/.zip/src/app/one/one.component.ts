import { Component } from '@angular/core';

@Component({
  selector: 'app-one',
  standalone: false,
  
  templateUrl: './one.component.html',
  styleUrl: './one.component.css'
})
export class OneComponent {

}
