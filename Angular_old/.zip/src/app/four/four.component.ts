import { Component } from '@angular/core';

@Component({
  selector: 'app-four',
  standalone: false,
  
  templateUrl: './four.component.html',
  styleUrl: './four.component.css'
})
export class FourComponent {

}
